import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from numpy import cos, sin, pi, exp
from mpl_toolkits import mplot3d

def singleDimension(f, df, x_range, lr, bestx, iterations):

    x = np.linspace(x_range[0], x_range[1], 100)
    y = f(x)
    fig, ax = plt.subplots()
    ax.plot(x, y)
    xall, yall = [], []
    lnall, = ax.plot([], [], 'ro')
    lngood, = ax.plot([], [], 'go', markersize=10)

def onestepderiv(frame):
        nonlocal bestx
        x = bestx - df(bestx) * lr
        bestx = x
        y = f(x)
        lngood.set_data(x, y)
        xall.append(x)
        yall.append(y)
        lnall.set_data(xall, yall)
        return lngood,

    ani = FuncAnimation(fig, onestepderiv, frames=range(iterations), interval=10, repeat=False)
    plt.show()
    
def twodimension(f, dx, dy, x_range, y_range, lr, bestx, besty, iterations):

    x = np.linspace(x_range[0], x_range[1], 100)
    y = np.linspace(y_range[0], y_range[1], 100)
    X, Y = np.meshgrid(x, y)
    Z = f(X, Y)
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('z')
    ax.plot_surface(X, Y, Z, cmap='Wistia')
    xall, yall, zall = [], [], []
    lnall, = ax.plot([], [], [], 'ro', markersize=10)
    lngood, = ax.plot([], [], [], 'go', markersize=15)
    
def onestepder2(frame):
        nonlocal bestx, besty
        x = bestx - dx(bestx, besty) * lr
        y = besty - dy(bestx, besty) * lr
        bestx = x
        besty = y
        z = f(x, y)
        lngood.set_data([x], [y])
        lngood.set_3d_properties([z])
        xall.append(x)
        yall.append(y)
        zall.append(z)
        lnall.set_data(xall, yall)
        lnall.set_3d_properties(zall)
        return lnall, lngood

    ani = FuncAnimation(fig, onestepder2, frames=range(iterations), interval=10, repeat=False)
    plt.show()
    
    # Define the functions and derivatives for f1 and f5
def f1(x):
    return x ** 2 + 3 * x + 8

def df1(x):
    return 2 * x + 3

def f5(x):
    return cos(x)**4 - sin(x)**3 - 4*sin(x)**2 + cos(x) + 1

def df5(x):
    return -4*sin(x)*cos(x)**3 - 3*cos(x)*sin(x)**2 - 8*sin(x)*cos(x) - sin(x)

xlim3 =  [-10, 10]
ylim3 =  [-10, 10]
def f3(x, y):
    return x**4 - 16*x**3 + 96*x**2 - 256*x + y**2 - 4*y + 262

def df3_dx(x, y):
    return 4*x**3 - 48*x**2 + 192*x - 256

def df3_dy(x, y):
    return 2*y - 4

xlim4 = [-np.pi, np.pi]
ylim4 = [-np.pi, np.pi]
def f4(x,y):
    return np.exp(-(x - y)**2) * np.sin(y)

def df4_dx(x, y):
    return -2 * np.exp(-(x - y)**2) * np.sin(y) * (x - y)

def df4_dy(x, y):
    return np.exp(-(x - y)*2) * np.cos(y) + 2 * np.exp(-(x - y)**2) * np.sin(y)(x - y)

