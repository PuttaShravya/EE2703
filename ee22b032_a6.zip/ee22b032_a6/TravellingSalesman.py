import random
import math
import matplotlib.pyplot as plt

def distance(cities, cityorder):
    tot_distance = 0
    N = len(cities)
    for i in range(N):
        x1, y1 = cities[cityorder[i]]
        x2, y2 = cities[cityorder[(i + 1) % N]]
        tot_distance += math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)
    return tot_distance

def plot_tsp(cities, cityorder):
    N = len(cities)
    x = [cities[cityorder[i]][0] for i in range(N)]
    y = [cities[cityorder[i]][1] for i in range(N)]
    x.append(x[0])
    y.append(y[0])
    plt.plot(x, y, 'o-')
    plt.title("Optimized TSP Route")
    # for i, (city_x, city_y) in enumerate(cities):
    #     plt.text(city_x, city_y, f'City {i + 1} ({city_x}, {city_y})', fontsize=8, ha='left')

    # plt.show()
    plt.show()

def tsp(cities, iteration=10000):
    N = len(cities)
    best_order = list(range(N))
    best_distance = distance(cities, best_order)

    T = 1.0
    T_min = 0.00001
    alpha = 0.995

    for i in range(iteration):
        # Generate two random indices for city swapping
        x1, x2 = random.sample(range(N), 2)

        # Swap cities
        new_order = best_order.copy()
        new_order[x1], new_order[x2] = new_order[x2], new_order[x1]

        new_distance = distance(cities, new_order)
        delta_distance = new_distance - best_distance

        if delta_distance < 0 or random.random() < math.exp(-delta_distance / T):
            best_order = new_order
            best_distance = new_distance

        T *= alpha

    return best_order

# Example usage:
# cities = [(2, 3), (5, 8), (9, 1), (4, 7), (6, 2), (8, 5), (1, 9), (3, 4), (7, 6), (10, 10)]
cities = []
with open('tsp40.txt', 'r') as file:
    next(file)  # Skip the first line
    for line in file:
        x, y = map(float, line.strip().split())
        cities.append((x, y))
best_order = tsp(cities)
print("Best Order:", best_order)
print("Best Distance:", distance(cities, best_order))

initial_distance = distance(cities, list(range(len(cities))))
best_order = tsp(cities)
final_distance = distance(cities, best_order)

# Calculate percentage improvement
percentage_improvement = ((initial_distance - final_distance) / initial_distance) * 100

print("Initial Distance:", initial_distance)
print("Final Distance:", final_distance)
print("Percentage Improvement:", percentage_improvement, "%")

# Plot the coordinates of the cities
city_x = [city[0] for city in cities]
city_y = [city[1] for city in cities]
plt.figure(figsize=(8, 6))
plt.scatter(city_x, city_y, marker='o', color='red', label='Cities')


# Plot the optimized route
# plot_tsp(cities, best_order)
# Plot the optimized route
plot_tsp(cities, best_order)
