import numpy as np
import csv
import matplotlib.pyplot as plt
# Path to the CSV file
csv_file = 'Admission_Predict_Ver1.1.csv'

# Initialize lists to store data
sno      = []
gre      = []
toefel   = []
uni      = []
sop      = []
lor      = []
cgpa     = []
research = []
chance   = []

# Read data from the CSV file and store it in respective lists
with open(csv_file, 'r') as file:
    csv_reader = csv.reader(file)
    next(csv_reader)      # Skip the header row
    for row in csv_reader:
        # Convert each value to float and append to respective lists
        value1 = float(row[0])
        value2 = float(row[1])
        value3 = float(row[2])
        value4 = float(row[3])
        value5 = float(row[4])
        value6 = float(row[5])
        value7 = float(row[6])
        value8 = float(row[7])
        value9 = float(row[8])
        sno.append(value1)
        gre.append(value2)
        toefel.append(value3)
        uni.append(value4)
        sop.append(value5)
        lor.append(value6)
        cgpa.append(value7)
        research.append(value8)
        chance.append(value9)

# Convert lists to NumPy arrays        
sno     = np.array(sno)
gre     = np.array(gre)
toefel  = np.array(toefel)
uni     = np.array(uni)
sop     = np.array(sop)
lor     = np.array(lor)
cgpa    = np.array(cgpa)
research= np.array(research)
chance  = np.array(chance)

# Stack the arrays to create the design matrix M for the linear regression
M = np.column_stack([gre*1,toefel*1,cgpa*0,cgpa**2,cgpa**1,lor**1,sop**2,research*lor,toefel*uni*1])

# Perform least squares regression to calculate the coefficients
p,_,_,_, = np.linalg.lstsq(M, chance, rcond=None)

# Print the regression equation with the calculated coefficients
print(f"{p[0]}gre1+{p[1]}*toefel1+{p[2]}*cgpa0+{p[3]}*cgpa2+{p[4]}*cgpa1+{p[5]}*lor1+{p[6]}*sop2+{p[7]}*research*lor+{p[8]}*toefel*uni*1")

# Scatter plot of predicted chance versus actual chance
plt.scatter((gre * 1) * p[0] + (toefel * 1) * p[1] + (cgpa * 1) * p[2] + (cgpa ** 2) * p[3] + (cgpa ** 1) * p[4] + (lor ** 1) * p[5] + (sop ** 2) * p[6] + research * lor * p[7] + toefel * (uni ** 1) * p[8], chance)

# Plot the line y = x for reference
plt.plot(chance,chance)

# Calculate R-squared (coefficient of determination)
actual = chance
predict = (gre * 1) * p[0] + (toefel * 1) * p[1] + (cgpa * 1) * p[2] + (cgpa ** 2) * p[3] + (cgpa ** 1) * p[4] + (lor ** 1) * p[5] + (sop ** 2) * p[6] + research * lor * p[7] + toefel * (uni ** 1) * p[8]

corr_matrix = np.corrcoef(actual, predict)
corr = corr_matrix[0,1]
R_sq = corr**2

# Print R-squared (R^2) score
print('r2 score for perfect model is',R_sq)

# Save the plot as an image file
plt.savefig("actual chance versus predicted chance")