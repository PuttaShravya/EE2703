import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def reading(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    x = []
    y = []
    for line in lines:
        values = line.split(' ')
        x.append(float(values[0]))
        y.append(float(values[1]))
    x = np.array(x)
    y = np.array(y)
    plt.plot(x, y)
    plt.show()
    return x,y

def plot_error(y_exp):
    plt.plot(x, y)
    plt.errorbar(x[::25], y[::25], np.std(y-y_exp), fmt='ro1')
    plt.show()
    
x,y=reading('dataset3.txt')
def plank_eqn(n,T):
    h=6.626e-34 
    k=1.38e-23
    c=3.0e8
    return (2*h*n**3)/(c**2*(np.exp((h*n)/(k*T))-1))
(T),cov=curve_fit(plank_eqn,x,y,p0=300)
print(T)
y_exp = plank_eqn(x,T)
plot_error(y_exp)
plt.plot(x, y)
plt.plot(x, y_exp)
plt.show()