import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def reading(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    x = []
    y = []
    for line in lines:
        values = line.split(' ')
        x.append(float(values[0]))
        y.append(float(values[1]))
    x = np.array(x)
    y = np.array(y)
    plt.plot(x, y)
    plt.show()
    return x,y

def plot_error(y_exp):
    plt.plot(x, y)
    plt.errorbar(x[::25], y[::25], np.std(y-y_exp), fmt='ro')
    plt.show()

x,y=reading('dataset1.txt')
M = np.column_stack([x, np.ones(len(x))])
(p1, p2), _, _, _ = np.linalg.lstsq(M, y , rcond=None)
y_exp = p1*x+p2
plot_error(y_exp)
print(f"The estimated equation is {p1} x + {p2}")
plt.plot(x, y)
plt.plot(x, y_exp)
plt.show()

