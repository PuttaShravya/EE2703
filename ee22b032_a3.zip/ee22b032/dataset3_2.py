import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def reading(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    x = []
    y = []
    for line in lines:
        values = line.split(' ')
        x.append(float(values[0]))
        y.append(float(values[1]))
    x = np.array(x)
    y = np.array(y)
    plt.plot(x, y)
    plt.show()
    return x,y

def plot_error(y_exp):
    plt.plot(x, y)
    plt.errorbar(x[::25], y[::25], np.std(y-y_exp), fmt='ro')
    plt.show()
    
kB = 1.380649e-23  # Boltzmann's constant (in J/K)
c = 3.0e8  # Speed of light (in m/s)

# Planck equation for Black Body radiation
def planck_equation(f, h, T):
    return (2 * h * f**3) / (c**2) / (np.exp((h * f) / (kB * T)) - 1)

# Fitting function for curve_fit
def fitting_function(f, h, T):
    return planck_equation(f, h, T)

# Initial guesses for parameters h and T
initial_guesses = [6.626e-34, 5000.0]

# Use curve_fit to estimate parameters h and T
params, covariance = curve_fit(fitting_function,x,y, p0=initial_guesses)

# Extract parameters h and T
h_estimate, T_estimate = params

# Calculate kB and c from h_estimate
kB_estimate = h_estimate / (2 * np.pi)
c_estimate = np.sqrt((h_estimate * x[0]**3) / (2 * kB_estimate))

# Generate the fitted curve using the estimated parameters
y_exp= planck_equation(x, h_estimate, T_estimate)
plot_error(y_exp)
plt.plot(x,y,x, intensity_fitted)
plt.plot(x,y_exp)
plt.show()