import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def reading(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    x = []
    y = []
    for line in lines:
        values = line.split(' ')
        x.append(float(values[0]))
        y.append(float(values[1]))
    x = np.array(x)
    y = np.array(y)
    plt.plot(x, y)
    plt.show()
    return x,y

def plot_error(y_exp):
    plt.plot(x, y)
    plt.errorbar(x[::25], y[::25], np.std(y-y_exp), fmt='ro')
    plt.show()
    
from scipy.optimize import minimize
x,y=reading('dataset2.txt')
def forier(x, a1, a2, a3, p1):
    return a1 * np.sin(2 * np.pi * p1 * x) + a2 * np.sin(2 * np.pi * 3 * p1 * x) + a3 * np.sin(2 * np.pi * 5 * p1 * x)

def objective(ampli, x, y):
    a1, a2, a3, p1 = ampli
    y_pred = forier(x, a1, a2, a3, p1)
    return np.sum((y - y_pred)**2)

initial_guess = [1, 1, 1, 0.3]
result = minimize(objective, initial_guess, args=(x, y), method='BFGS')
a1, a2, a3, p1 = result.x

y_exp = forier(x, a1, a2, a3, p1)
plot_error(y_exp)
plt.plot(x, y)
plt.plot(x, y_exp)
plt.show()

# solving for amplitudes using curve_fit
(a1,a2,a3,p1),cov = curve_fit(forier,x,y,p0=(1,1,1,0.3))
print(a1,a2,a3,p1)
y_exp=forier(x,a1,a2,a3,p1)
plot_error(y_exp)
plt.plot(x, y)
plt.plot(x, y_exp)
plt.show()



