# Assignment 3 Curve Fit

In this Assignment, we performed curve fitting on three datasets: Dataset 1, Dataset 2, and Dataset 3.

## Dataset 1

### Curve fit for a data with noise representing a straight line

- For the dataset 1 we were said to assume it to be a straight line with some noise added to it. 

- The curve fit estimation is done by assuming it to be a `straight line with noise` then using the `least squares curve
fitting` method to estimate the curve.


- The `M matrix` here is constructed in the same way as shown in the `curvefit` notebook by sir.

- After getting the `M matrix` we pass that matrix to the python function `numpy.linalg.lstsq` to get the 
2 unknown parameters `m and c` of the estimated line `y = m * x + c`.

> - The values i got were `m = 2.7911242454149177` and `c = 3.848800101430744`. 
## Dataset 2

### Curve fit for sum of 3 sin waves with some noise and offset 

- For the dataset 2 we were given that ot os of the form `y = p0 + p1 * sin(wx) + p2 * sin(3wx) + p3 * sin(5wx)` where `w = 2π/T is the angular frequency`.

- This estimation was done via 2 methods:-

#### 1. Linalg.lstsq function:

> - To estimate this `p values` in this method we had to first get the `time period` of the graph.
> - This was done roughly via the logic that for a sum of sin wave the max value and the largest -ve value are equal in magnitudes if the offset is 0
and are a distance of `T/2`.
> - Once we get `T` we try to form the `m matrix` of row length = no of datapoints.
\[m  = 
\begin{pmatrix}
  1 & sin(wx1) & sin(3wx1) & sin(5wx1)\\
  1 & sin(wx2) & sin(3wx2) & sin(5wx2)\\
  . & . & . & . \\
  . & . & . & . \\
  . & . & . & . \\
\end{pmatrix}
\]
- After this just using the function to get the parameters as
> - The parameter values are `a1=6.011100025981616,  a2=2.0014586391445546  ,a3=0.9809069565555802  ,p1=0.339991412207077352`

#### 2. Curve_fit function:

> - For this function we have the unknown parameters as `p0`.
> - We input this in the curve_fit function with some `initital guess`.
> - For the parameters for which `y depends on linearly (like all p values)`can be given anything as an initial guess but for `T` we need to give a close value for the `curve_fit function to converrge`.
> - The parameter values are `a1=6.011100025981616,  a2=2.0014586391445546  ,a3=0.9809069565555802  ,p1=0.339991412207077352`


## Dataset 3

### Curve Fit for a data representing the Black Body Radiaition
- This dataset or programme had two parts
#### Part 1 - Curve fit to Find only T
> - In part 1 we only have to find the `Temparature T` for the given dataset comprised of the `Black Body Radiation value Y` and `Frequency X` of the radiation.
> - The formula is $B(f, T) = \frac{2hf^3}{c^2} \frac{1}{e^(\frac{hf}{tk}-1)}$.
> - Here T is the only unknown parameter and its initial guess was taken as 300K.
> - From the curve_fit function the Temp `T = 5001.41337489`

#### Part 2 - Curve fit to find all h, c, k, T
> - Here we tried to get the values of the constants `h, c, k` as well from the curve fit function.
> - The formula $B(f, T) = \frac{2hf^3}{c^2} \frac{1}{e^(\frac{hf}{tk}-1)}$
can be reduced to $B(f, T) = p1f^3\frac{1}{e^(p2f-1)}$ where $p1 = \frac{2h}{c^2}$ and $p2 = \frac{h}{tk}$.
> - Since we are using curve fit to find `h, c, k and T` the values we get are not accurate even if we give very inital guess is beacuse the above formula effectively has only `2 parameters`.
> - So after gettin the values of `h, c, k and T` and find `p1` and `p2` we will notice that it is equal to the actual ratio of the quantities.
> - This simply means there are many values of `h, c, k and T` which can be given by the curve fit funtion but the ratio $p1 = \frac{2h}{c^2}$ and $p2 = \frac{h}{tk}$ will always be the same.
> - Only when we give initial guess as their own value we get almost simmilar value.
> - The values of `h, c, k and T` from the curve fit are `h =2.881433427421395e-33, c =300000000.0 , k =1.380649e-23 , T =5001.41337489 `. 
