def matmul(A, B):
    l=[]
    
    for (i,j) in zip(range(len(A)),range(len(B))):
        if len(A[i])!=len(A[0]) or len(B[j])!=len(B[0]):         # checking for all rows are of equal length and all columns are of equal length
            raise TypeError("Non matrices are not valid inputs") 
    
    if(len(A[0])!=len(B)):
        raise ValueError("Axes of matrices are not matched")     # columns of A should be equal to rows of B 
        
    else:
        for i in range(len(A)):                                  # loop for rows in A
            List=[]                                              # initiating a list to store the lists of rows of resulting matrix
            for j in range(len(B[0])):                           # loop for columns in B
                sum=0                                            # initiating variable for each element of resulting matrix
                for k in range(len(B)):                          # loop for rows in B
                    if not isinstance(A[i][k],(int,float)):
                        raise TypeError("Non numeric inputs are not valid")  #checking non numeric inputs in matrix
                    if not isinstance(B[k][j],(int,float)):
                         raise TypeError("Non numeric inputs are not valid")  #checking non numeric inputs in matrix
                    sum+=A[i][k]*B[k][j]                         # element obtained from multiplying a row with column, clears when j incriments
                List.append(sum)                                 # store element of a row in a list, clears when i incriments
            l+=[List]                                            # adding all list of rows to a new list to form matrix
    
    return l                                                     # returning final list