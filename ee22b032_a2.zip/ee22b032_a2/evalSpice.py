import numpy as np
import math
import os

def evalSpice(filename):
    def check(line,node_mapping):
        compfull=line[0]
        component=line[0][0]
        if line[1][0] =='n' or line[2][0]=='n':
                if line[1]=='GND':
                    node1=0
                    node2=int(line[2][1])
                elif line[2]=='GND':
                    node2=0
                    node1=int(line[1][1])
                else:
                    node1, node2 = int(line[1][1]), int(line[2][1])
                node_mapping[node1] = line[1]  # Store the mapping of node number to name
                node_mapping[node2] = line[2]  # Store the mapping of node number to name
        else:
            if line[1]=='GND':
                node1=0
                node2=int(line[2])
            elif line[2]=='GND':
                node2=0
                node1=int(line[1])
            else:
                node1, node2 = int(line[1]), int(line[2])
            node_mapping[node1] = line[1]  # Store the mapping of node number to name
            node_mapping[node2] = line[2]  # Store the mapping of node number to name
        if line[3]=='dc' or line[3]=='ac' :
            if line[3]=='ac':
                vsource = line[3]
                phi= float(line[5])
            if line[3]=='dc':
                vsource = line[3]
                phi= None
            acdc=vsource
            phase=phi
            magnitude = float(line[4])
            value = magnitude
        else:
            value = float(line[3])
            acdc=None
            phase=None
        return compfull,component,node1,node2,value,acdc,phase


    def parse_line(line,node_mapping):
        line = line.strip().split()
        C=['R','C','L','V','I']
        for i in C:
            if line[0].startswith(i):
                return check(line,node_mapping)
        
    def nodecount(components):
        node=set()
        v=0
        for t in components:
            node.add(t[1])
            node.add(t[2])
        for t in components:
            if t[0]=='V':v=+1
        return node,v
    
    def read_netlist(filename):
        with open(filename, 'r') as file:
            components = []
            comps=[]
            node_mapping={}
            for line in file:
                if not line.startswith('.circuit') and not line.startswith('.end') and not line.startswith('.ac'):
                    if line.startswith('R') or line.startswith('C') or line.startswith('L') or line.startswith('V') or line.startswith('I'):
                        compfull,component, node1, node2, value,acdc,phase = parse_line(line,node_mapping)
                        components.append([component, node1, node2, value,acdc,phase])
                        comps.append(compfull)
                        vsource=''
                        freq=0
                if line.startswith('.ac'):
                    split=line.split()
                    vsource=split[1]
                    freq=float(split[2])*2*math.pi
            return comps,components,vsource,freq,node_mapping
    
    def MNAmatrix(components,f):
        vtype=list()
        l,v=nodecount(components)
        u=max(l)
        nodes=list(l)
        node_dict = {node: i for i, node in enumerate(nodes)}
        k=0
        p=0
        n=u+v
        A=[]
        B=[]
        q = complex(0,1)
        A=[[0 for j in range(n+1)] for i in range(n+1)]
        B=[0 for j in range(n+1)]
        if f!=0:
            A=np.array(A)
            B=np.array(B)
            A=A*q
            B=B*q
            A = A.tolist()
            B = B.tolist()
        for t in components:
            i=node_dict[t[1]]
            j=node_dict[t[2]]
            k=node_dict[0]
            k=node_dict[0]
            m=t[3]
            if t[0]=='R':
                A[i][i]=A[i][i] +1/m
                A[j][j]=A[j][j] +1/m
                A[i][j]=A[i][j] -1/m
                A[j][i]=A[j][i] -1/m
            elif t[0]=='I':
                vtype.append(t[4])
                B[i]-=m
                B[j]+=m
            elif t[0]=='V':
                vtype.append(t[4])
                if p<v:
                    p=+1
                    l=p+u
                    A[l][i] += 1
                    A[l][j] -= 1
                    A[i][l] += 1
                    A[j][l] -= 1
                    B[l]-=m
            elif t[0]=='C':
                if f==0:
                   #print("This function cannot compute DC circuit with a capacitance")
                   raise ValueError('Only V, I, R elements are permitted')
                else:
                    A[i][i]=A[i][i] + (q*f*m)
                    A[j][j]=A[j][j] + (q*f*m)
                    A[i][j]=A[i][j] - (q*f*m)
                    A[j][i]=A[j][i] - (q*f*m)    
            elif t[0]=='L':
                if f==0:
                   #print("This function cannot compute DC circuit with a inductance")
                   raise ValueError('Only V, I, R elements are permitted')
                else:
                    A[i][i]=A[i][i] + 1/(q*f*m)
                    A[j][j]=A[j][j] + 1/(q*f*m)
                    A[i][j]=A[i][j] - 1/(q*f*m)
                    A[j][i]=A[j][i] - 1/(q*f*m)  
        A=np.array(A)
        B=np.array(B)
        B= np.squeeze(B)
        A = np.delete(A, k, axis=0)
        A = np.delete(A, k, axis=1)
        B = np.delete(B, k)
        A = A.tolist()
        B = B.tolist()
        vtype=list(set(vtype))
        if len(vtype) == 1 and vtype[0] == 'dc':
            return A,B,vtype
        elif len(vtype) == 1 and vtype[0] == 'ac':
            return A,B,vtype
        else:
            return

    def gaussian_elimination(A, B):
        n = len(A)
        B = np.array(B) 
        augmented_matrix = np.hstack((A, B.reshape(-1, 1)))

        for i in range(n):
            max_row = max(range(i, n), key=lambda j: abs(augmented_matrix[j, i]))
            augmented_matrix[[i, max_row]] = augmented_matrix[[max_row, i]]

            if augmented_matrix[i, i] == 0:
                raise ValueError("Singular matrix - circuit may have a problem.")

            for j in range(i + 1, n):
                factor = augmented_matrix[j, i] / augmented_matrix[i, i]
                augmented_matrix[j, i:] -= factor * augmented_matrix[i, i:]

        x = np.zeros(n)
        for i in range(n - 1, -1, -1):
            x[i] = (augmented_matrix[i, -1] - np.dot(augmented_matrix[i, i + 1:n], x[i + 1:])) / augmented_matrix[i, i]

        return x

    def has_voltage_loop(components):
        # Create a set to store connected nodes of voltage sources
        connected_nodes = set()

        for component in components:
            if component[0] == 'V':
                node1 = component[1]
                node2 = component[2]

                # Check if node1 of one voltage source is node2 of another, and vice versa
                if (node1, node2) in connected_nodes or (node2, node1) in connected_nodes:
                    return True

                # Add the nodes to the set
                connected_nodes.add((node1, node2))
                connected_nodes.add((node2, node1))

        return False

    def has_current_node(components):
        # Create a dictionary to count current sources entering each node
        node_current_count = {}

        for component in components:
            if component[0] == 'I':
                node1 = component[1]
                node2 = component[2]

                # Count current sources entering each node
                node_current_count[node1] = node_current_count.get(node1, 0) + 1
                node_current_count[node2] = node_current_count.get(node2, 0) + 1

        # Check if there's a node with all current sources entering it (excluding GND)
        for count in node_current_count.values():
            if count == len(components) and count > 1:  # Ensure at least two current sources
                return True

        return False    

    try:
        comps,components, vsource, freq,node_mapping = read_netlist(filename)
        A, B, vtype = MNAmatrix(components, freq)
        sources=[]
         # Check for voltage loop
        if has_voltage_loop(components):
            raise ValueError('Circuit error: no solution')
        
        # Check for current node
        if has_current_node(components):
            raise ValueError('Circuit error: no solution')
        for i in comps:
            if (i.startswith('V') or i.startswith('I')):
                sources.append(i)
        """if vtype[0] == 'ac':
            print('The given source is an AC source')
        elif vtype[0] == 'dc':
            print('The given source is a DC source')"""
        # Solve the circuit equations using Gaussian elimination
        x = gaussian_elimination(A, B)
        # Create dictionaries for node voltages and branch currents
        V = {}
        I = {}
        # Extract the node names from the components list
        nodes = list(set([component[1] for component in components] + [component[2] for component in components]))
        # Create a dictionary to map node indices to their names
        # Set the GND node voltage explicitly to 0
        # Populate V dictionary with node voltages, reversing the signs and using mapped names
        for i, node in enumerate(nodes):
            if node != 'GND':
                try:
                    V[node_mapping[i+1]] = -x[i]  # Reverse the sign and use mapped name
                except KeyError:
                    continue
        V['GND'] = 0.0
         # Reverse the sign
        sourceV={}
        if sources:
            sourceV[sources[0]]=-x[-1]
            sources.pop(0)
        Vnew=[]
        Vnew.append(V)
        Vnew.append(sourceV)
        # Populate I dictionary with branch currents
        for component in components:
            if component[0] == 'I':
                name, node1, node2, value, _, _ = component
                current = (x[nodes.index(node1)] - x[nodes.index(node2)]) / value
                I[sources[0]] = current
        V=tuple(Vnew)
        return V

    except FileNotFoundError:
        raise FileNotFoundError('Please give the name of a valid SPICE file as input')

    except TypeError:
        raise ValueError('Malformed circuit file')

