###SPICE simulation in Python

##This assignment gives details on implementing a basic SPICE simulator for electronic circuits in Python.  Detailed [instructions](docs/INSTRUCTIONS.md) are given in the documentation folder. 

The code  provided is a Python script for evaluating SPICE netlists, which are used to describe electronic circuits. The code parses a SPICE netlist, builds a Modified Nodal Analysis (MNA) matrix, and then solves it to calculate node voltages and branch currents in the circuit.

Here's an overview of the code's approach and some of its key components:

##Parsing the Input Netlist:
The code begins by defining a function called evalSpice(filename) that takes the filename of a SPICE netlist as input.
It defines several helper functions within this main function.
The read_netlist(filename) function reads the netlist, extracts component details, and stores them in a list.

The parse_line function reads the spice circuit line by line and splits it according to white spaces.
The nodecount fuction reads the components obtained and add all nodes to a list, returns the list and count of nodes.
The MNAmatrix(components, f) function builds the MNA matrix. It initializes an empty matrix (A) and a vector (B) for the system of linear equations.
It iterates through the components in the netlist and populates the MNA matrix according to the type of components (resistor, capacitor, inductor, voltage source, current source).
The matrix elements are modified based on whether the circuit is operating in DC or AC (frequency-dependent) mode.
The code uses complex numbers (q) to handle AC components.

##gaussain elemination:
The gaussian_elimination(A, B) function solves the system of linear equations using Gaussian elimination.
It ensures that the matrix is not singular (i.e., it has a unique solution).
It returns the node voltages.
circut validity:
The code includes checks to ensure the validity of the circuit:
It checks for voltage loops in the circuit.
It checks for nodes with all current sources entering them.

##how it will handle the inputs:
The code includes error handling using try-except blocks. It checks for errors such as file not found, malformed circuit files, or circuit errors like voltage loops or current nodes.
When an error is detected, it raises an appropriate exception.
It has few limitations:
The code assumes that the input SPICE netlist is correctly formatted and does not perform extensive validation.
It only handles simple circuit components (resistors, capacitors, inductors, voltage sources, and current sources) and does not support more complex devices.
The code may not handle all possible circuit configurations or edge cases.
and code uses try-except blocks to catch and raise specific exceptions for different types of input errors. For example, it raises FileNotFoundError for missing files and ValueError for malformed circuits or circuit errors.
Users should ensure that the input netlist is correctly formatted and that it describes a valid electronic circuit.
in overall ,this code parses SPICE netlists, builds an MNA matrix, solves it to find node voltages and branch currents, and includes error handling to deal with common input issues and circuit errors. However, it may not cover all possible circuit scenarios, and it assumes well-formed input netlists.
The approach for this code is done by taking help from my peers hasmitha,srivalli,yasaswi,abhignya.